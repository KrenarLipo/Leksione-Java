// Main.java
// Ketu vetem SHTOJME deget dhe shfaqim rezultatin.

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Zinxhiri i degeve - e njejta banke, adresa te ndryshme
        ArrayList<Bank> deget = new ArrayList<>();

        deget.add(new Bank("Banka Kombetare", "Rruga e Kavajes, Tirane", 500));
        deget.add(new Bank("Banka Kombetare", "Bulevardi Zogu I, Tirane", 750));
        deget.add(new Bank("Banka Kombetare", "Rruga Egnatia, Durres", 620));
        deget.add(new Bank("Banka Kombetare", "Lagjja 1, Shkoder", 430));

        // Printojme gjithe zinxhirin - me for klasik me indeks
        System.out.println("Zinxhiri i degeve (" + deget.size() + " dege):");
        for (int i = 0; i < deget.size(); i++) {
            Bank b = deget.get(i);
            System.out.println("  - " + b.adresa + "  |  kapaciteti: " + b.kapaciteti);
        }

        // Gjejme degen me kapacitetin me te larte dhe shfaqim detajet e plota
        Bank kryesorja = Bank.meKapacitetinMax(deget);

        System.out.println();
        System.out.println("=== Dega me kapacitetin me te larte ===");
        kryesorja.printoDetajet();
    }
}
