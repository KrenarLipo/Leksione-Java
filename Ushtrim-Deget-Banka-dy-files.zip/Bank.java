// Bank.java
// Nje objekt Bank = nje dege e bankes: emri, adresa dhe kapaciteti i saj.
// Ketu jetojne TE GJITHA funksionet e logjikes.

import java.util.ArrayList;

public class Bank {
    String emri;
    String adresa;
    int kapaciteti;

    // Konstruktori - dega lind e plote
    Bank(String emri, String adresa, int kapaciteti) {
        this.emri = emri;
        this.adresa = adresa;
        this.kapaciteti = kapaciteti;
    }

    // Metode instance - printon detajet e plota te KESAJ dege
    void printoDetajet() {
        System.out.println("Banka:      " + emri);
        System.out.println("Adresa:     " + adresa);
        System.out.println("Kapaciteti: " + kapaciteti);
    }

    // Metode STATIKE - vegel mbi listen, s'i perket asnje dege konkrete.
    // Modeli i maksimumit (leksioni 3), por mbi objekte Bank.
    static Bank meKapacitetinMax(ArrayList<Bank> lista) {
        if (lista.size() == 0) {
            return null;               // liste bosh - s'ka maksimum
        }
        Bank max = lista.get(0);       // nisim me degen e pare (indeksi 0)
        for (int i = 1; i < lista.size(); i++) {   // vazhdojme nga indeksi 1
            if (lista.get(i).kapaciteti > max.kapaciteti) {
                max = lista.get(i);    // gjetem me te madhe - e ruajme
            }
        }
        return max;
    }
}
