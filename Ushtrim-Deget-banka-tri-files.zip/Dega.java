// Dega.java
// Nje dege (filial) e bankes: adresa + kapaciteti i saj.

public class Dega {
    String adresa;
    int kapaciteti;

    // Konstruktori - dega lind e plote, me adrese dhe kapacitet
    Dega(String adresa, int kapaciteti) {
        this.adresa = adresa;
        this.kapaciteti = kapaciteti;
    }
}
