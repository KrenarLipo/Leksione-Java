// Bank.java
// Banka mban EMRIN e saj dhe nje liste dinamike degesh (zinxhiri i adresave).

import java.util.ArrayList;

public class Bank {
    String emri;
    ArrayList<Dega> degat;

    // Konstruktori - banka lind me emer dhe me liste bosh degesh
    Bank(String emri) {
        this.emri = emri;
        this.degat = new ArrayList<>();
    }

    // Shton nje dege te re ne zinxhirin e bankes
    void shtoDege(String adresa, int kapaciteti) {
        degat.add(new Dega(adresa, kapaciteti));
    }

    // Modeli i MAKSIMUMIT (leksioni 3), por mbi objekte:
    // krahasojme fushen kapaciteti te cdo dege
    Dega degaMeKapacitetinMax() {
        if (degat.size() == 0) {
            return null;   // s'ka dege - s'ka maksimum
        }
        Dega max = degat.get(0);           // nisim me degen e pare
        for (Dega d : degat) {
            if (d.kapaciteti > max.kapaciteti) {
                max = d;                   // gjetem me te madhe - e ruajme
            }
        }
        return max;
    }

    // Printon te gjithe zinxhirin e degeve te bankes
    void printoTeGjithaDegat() {
        System.out.println("Banka: " + emri + "  (" + degat.size() + " dege)");
        for (Dega d : degat) {
            System.out.println("  - " + d.adresa + "  |  kapaciteti: " + d.kapaciteti);
        }
    }
}
