// Main.java
// Krijon nje banke me disa dege dhe shfaq detajet e plota
// te deges me kapacitetin me te larte.

public class Main {
    public static void main(String[] args) {
        // 1. Krijojme banken (nje objekt i vetem Bank)
        Bank banka = new Bank("Banka Kombetare");

        // 2. Shtojme zinxhirin e degeve - e njejta banke, adresa te ndryshme
        banka.shtoDege("Rruga e Kavajes, Tirane", 500);
        banka.shtoDege("Bulevardi Zogu I, Tirane", 750);
        banka.shtoDege("Rruga Egnatia, Durres", 620);
        banka.shtoDege("Lagjja 1, Shkoder", 430);

        // 3. Shfaqim gjithe zinxhirin
        banka.printoTeGjithaDegat();

        // 4. Gjejme degen me kapacitetin me te larte...
        Dega kryesorja = banka.degaMeKapacitetinMax();

        // 5. ...dhe shfaqim detajet e saj te plota
        System.out.println();
        System.out.println("=== Dega me kapacitetin me te larte ===");
        System.out.println("Banka:      " + banka.emri);
        System.out.println("Adresa:     " + kryesorja.adresa);
        System.out.println("Kapaciteti: " + kryesorja.kapaciteti);
    }
}
