import javax.swing.*;
import java.awt.*;

public class Exchange {
    
    public static void main(String[] args){
        JFrame dritarja = new JFrame("Lek->Euro");
        dritarja.setSize(400,250);
        dritarja.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dritarja.setLayout(new GridLayout(4,2,7,5));
        JTextField fushaLeke = new JTextField();
        JTextField fushaKursi = new JTextField();
        JButton butoni = new JButton("Konverto");
        JLabel rezultati = new JLabel("Monedha konvertuar! ");

        butoni.addActionListener(e -> {
            try {
                double leke = Double.parseDouble(fushaLeke.getText());
                double kursi = Double.parseDouble(fushaKursi.getText());
                double euro = (leke * kursi)/10000;
                rezultati.setText("Rezultati: " + euro + " euro");
            } catch (NumberFormatException ex) {
                rezultati.setText("Gabim: shkruaj numra!");
            }
        });


          /// Detyre shtepie per dollarin
        dritarja.add(new JLabel("Shuma ne leke"));
        dritarja.add(fushaLeke);
        dritarja.add(new JLabel("Kursi"));
        dritarja.add(fushaKursi);
        dritarja.add(butoni);
        dritarja.add(rezultati);
        dritarja.setVisible(true);
    }
}
