import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.*;
import java.awt.*;
 
public class Skedari {
  public static void main(String[] args) throws IOException {
    FileWriter shkrues = new FileWriter("pershendetje.txt");
    shkrues.write("Pershendetje nga Java! hhsrhgsrhshdhh ggggg!");
    shkrues.close();   // MBYLLE gjithmone!
    System.out.println("Skedari u krijua.");

    //File-writeri me append 
    try{
        FileWriter shkruesappend = new FileWriter("Append.txt",true);
        shkruesappend.write("Tekst i ri\n");
        shkruesappend.close();
    }catch (IOException e) {
    System.out.println("Gabim: " + e.getMessage());
}

//     try (PrintWriter shkrues1 = new PrintWriter("nota.txt")) {
//     shkrues1.println("Ana: 9");
//     shkrues1.println("Beni: 7");
//     System.out.println("U ruajt (dhe u mbyll vete).");
// } catch (IOException e) {
//     System.out.println("Gabim: " + e.getMessage());
// }


    PrintWriter shkrues1 = new PrintWriter("lista.txt");
    shkrues1.println("Molle");
    shkrues1.println("Buke");
    shkrues1.print("Qumesht\t");
    shkrues1.print("Kos");
    shkrues1.close();

    //Leximi i skedareve egzistues
    File skedari = new File("Append.txt");
    Scanner lexues = new Scanner(skedari);
    
    while (lexues.hasNextLine()) {
        String rreshti = lexues.nextLine();
        System.out.println("Lexova: " + rreshti);
    }
    lexues.close();

    //File write me gui
    JFrame dritarja = new JFrame("Pershendetje Swing");
    dritarja.setSize(400, 200);
    dritarja.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    dritarja.setLayout(new FlowLayout());

    JTextArea zona = new JTextArea();
    JButton ruaj = new JButton("Ruaj ne skedar");

     dritarja.add(zona);
     dritarja.add(ruaj);
     dritarja.setVisible(true);
    
    ruaj.addActionListener(e -> {
        try (FileWriter shkrues2 =
                new FileWriter("shenimet.txt")) {
            shkrues2.write(zona.getText());
            JOptionPane.showMessageDialog(dritarja, "U ruajt!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                dritarja, "Gabim: " + ex.getMessage());
        }
    });

  }
}