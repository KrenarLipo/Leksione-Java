import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    
    // Your program begins with a call to main()
    public static void Kaltrina(String s, int mosha){
        System.out.println("Emri im eshte " + s + " dhe jam "+mosha+" vjec" );
    }

    public static int notat (int nota1, int nota2){
        int mesatarja = (nota1 + nota2)/2;
        return mesatarja;
    }
    // Funksioni per te gjetur mesataren e arrays
    static double mesatarja(int[] v){
       int shuma = 0;
       for(int x : v){
        shuma += x;
       }
       return (double) shuma/v.length;
    }


   
   /* ======== Mbyllja kodi i trashegimise */



    public static void main(String[] args)
    {


        ArrayList<String> emrat = new ArrayList<>();
        
        emrat.add("Ana");        // shton ne fund
        emrat.add("Beni");
        emrat.add("Klea");
        emrat.add("Kaltrina");
        emrat.add("Arla");
        
        System.out.println(emrat.get(4));    // Beni
        System.out.println(emrat.size());    // 3
        emrat.remove(0); 
        System.out.println(emrat.size());
        System.out.println(emrat.get(1));                      

        int[] notat2 = {3,4,7,9,10};
        System.out.println(mesatarja(notat2));


        //Kaltrina("Kaltrina",19);
        // System.out.print("Ka mesataren e mepostme:\n");
        // int vlera = notat(9,9);
        // System.out.println(vlera+1);
        // Prints "Hello, World" to the terminal window.
        /*int mosha = 16;
        if(mosha >= 18){
            System.out.println("Jeni maxhorien!");
        }else{
            System.out.println("Nuk keni plotesuar moshen!");
        }*/
    //    for(int i=1; i<=6; i++){
    //     if(i % 2 == 0){
    //         System.out.println(""+i+" Eshte numer cift"); 
    //     }else{
    //         System.out.println("Numri " + i + " eshte tek");
    //     }
    //    }

    //  int[] notat = {4, 7, 9, 5, 8};
    //  float shuma = 0;
    //  float mestarja = 0;
     
    //  for(int i=0; i<notat.length; i++){
    //     shuma += notat[i];
    //  }

    //  mestarja = shuma/notat.length;

     //System.out.println("Totali = "+ shuma);
     //System.out.println("Mesatarja eshte "+mestarja);
     
     Scanner sc = new Scanner(System.in);

     System.out.print("Si quhesh? ");
     String emri = sc.nextLine();
    
    System.out.print("Sa vjec je? ");
    int age = sc.nextInt();

    System.out.println("Pershendetje: "+emri+" Ju jeni: "+age+" vjec!");

    /* Shtimi i notave */
    System.out.println("================= Fillojme me notat ========================");
    System.out.print("Sa nota do shtoni: ");
    int n = sc.nextInt();
    int[] notat = new int[n];

    int shuma = 0;

    for (int i = 0; i < n; i++) {
    System.out.print("Nota " + (i + 1) + ": ");
    notat[i] = sc.nextInt();
    shuma = shuma + notat[i];
    }

    System.out.println("Shuma eshte: "+shuma+ " dhe ka gjithsej " +n+" nota");
    float mesatare = (float)shuma/n;
    System.out.println("Mesatarja eshte: "+mesatare);



    }
}