import javax.swing.*;
import java.awt.*;
 
public class Grafika {

  static int numeruesi = 0;
  public static void main(String[] args) {
   JFrame dritarja = new JFrame("Pershendetje Swing");
  dritarja.setSize(400, 200);
  dritarja.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  dritarja.setLayout(new FlowLayout());
 
JLabel etiketa = new JLabel("Shkruaj emrin:");
JLabel etiketa2 = new JLabel("Buton i paklikuar | Klikime 0");
JTextField fusha = new JTextField(15);
JButton butoni = new JButton("Pershendet");
JLabel rezultati = new JLabel("");

 dritarja.add(etiketa);   // shto ne dritare
 dritarja.add(fusha);
 dritarja.add(butoni);
  dritarja.add(rezultati);
  dritarja.add(etiketa2);
  dritarja.setVisible(true);
 
butoni.addActionListener(e -> {
    String emri = fusha.getText();   // lexo fushen
    rezultati.setText("Pershendetje, " + emri + "!");
    numeruesi = numeruesi + 1;
    etiketa2.setText("Butoni u klikua: " + numeruesi + " here");
});
 }
}
