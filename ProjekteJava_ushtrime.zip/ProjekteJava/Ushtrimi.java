public class Ushtrimi {

   

public static class Person {
   String emri;
   protected int mosha;
    Person(String emri) {
        this.emri = emri;
    }


}
 
public static class Studenti extends Person {
    String fakulteti;
 
    Studenti(String emri, String fakulteti) {
        super(emri); 
             // 1. ndertohet pjesa Person
        this.fakulteti = fakulteti;   // 2. pjesa e re
    }

        void test() {
        //System.out.println(emri);    // OK - protected
        System.out.println(mosha);   // GABIM - private!
    }



}
 

    public static void main(String[] args){
  Studenti s = new Studenti("Ana", "Informatike");
      System.out.println("Emri eshte "+s.emri+" dhe fakultetti eshte: " +s.fakulteti);

      s.mosha = 34;
      s.test();


       int[] klasa = new int[3];
            // {null, null, null} - vetem VENDE bosh!
    
         klasa[0] = 1;    // mbushim
         klasa[1] = 2;
         klasa[2] = 5;

          
for (int i = 0; i < klasa.length; i++) {
    System.out.println("Numri # "+klasa[i]);
}

int[] v = new int[4];
v[0] = 3;
v[1] = 7;
v[3] = 4;
 
System.out.println(v[0] + v[1]+ v[2] + v[3]);




    }


}